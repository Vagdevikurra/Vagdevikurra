# Enterprise Auth Insights — Dashboard Restructure Plan
## Parent-Child Architecture with Stakeholder Reference Styling

---

## ARCHITECTURE OVERVIEW

```
PARENT: Executive Summary (1 page)
  ├── CHILD 1: Digital Auth Deep Dive (links from auth KPIs)
  ├── CHILD 2: OTP & Step-Up Analysis (links from step-up KPIs)  
  ├── CHILD 3: Customer Adoption & Friction (links from customer KPIs)
  └── CHILD 4: Channel & LOB Breakdown (links from channel donut)
```

Each child page has a **← Back to Executive Summary** button (use a blank button with Action = Page Navigation).

---

## DESIGN SYSTEM (matching stakeholder's reference dashboards)

### Color Palette
The reference dashboards use a **dark olive sidebar + white content area**. Here's the exact style:

| Element | Color | Hex |
|---|---|---|
| Sidebar background | Dark olive | #4A4A2E or #3D3D1E |
| Sidebar text | White | #FFFFFF |
| KPI numbers (sidebar) | White, bold | #FFFFFF |
| KPI labels (sidebar) | Light gray | #D4D4C8 |
| Content background | White | #FFFFFF |
| Table headers | Dark gray | #333333 |
| Table borders | Light gray | #CCCCCC |
| Primary chart color | Blue | #4472C4 |
| Secondary chart color | Red/Orange | #C0504D |
| Accent | Green | #70AD47 |
| Page title | Black, centered | #000000 |

### Layout Template (for every page)
```
┌──────────────┬─────────────────────────────────────────────┐
│  SIDEBAR     │          PAGE TITLE (centered, large)       │
│  (dark bg)   │                                             │
│              │  ┌─────────────────────────────────────────┐ │
│  Date Range  │  │         DATA TABLE                      │ │
│  [slider]    │  │  Year | Month | Metric1 | Metric2 | ...│ │
│              │  │  2025 | Jan   | 32.4M   | 17.7M   | ...│ │
│  Filter 1    │  │  ...                                    │ │
│  [button]    │  │  Total | ...                            │ │
│              │  └─────────────────────────────────────────┘ │
│  Filter 2    │                                             │
│  [button]    │  ┌──────────────────┐ ┌──────────────────┐  │
│              │  │   TREND CHART    │ │   PIE/DONUT      │  │
│  KPI Card 1  │  │   (bar/line)     │ │   (proportion)   │  │
│  740.3M      │  │                  │ │                   │  │
│  label       │  └──────────────────┘ └──────────────────┘  │
│              │                                             │
│  KPI Card 2  │                                             │
│  136.7M      │                                             │
│  label       │                                             │
│              │                                             │
│  KPI Card 3  │                                             │
│  658.3M      │                                             │
│  label       │                                             │
│              │                                             │
│  [nav links] │                                             │
│  to children │                                             │
└──────────────┴─────────────────────────────────────────────┘
```

---

## PAGE-BY-PAGE DESIGN

### PARENT PAGE: Executive Summary

**Purpose**: One-glance health check. Stakeholder opens this, gets the story in 10 seconds, clicks into detail only if something looks off.

**Sidebar (dark olive):**
- Date Range slicer (range slider, like reference)
- Channel filter (dropdown or buttons)
- LOB filter (dropdown)
- KPI stack:
  - Total Auth Attempts → 3.0B
  - Auth Success Rate → 99.66%
  - Step-Up Rate → 0.81%
  - Digitally Active Customers → 2.0M
  - OTP Users → 2.0M

**Content area:**

**Row 1 — Summary Table (this is what stakeholder wants)**
```
| Month   | Auth Attempts | Success Rate | Failure Rate | Step-Up Rate | Sessions  | Unique Customers |
|---------|--------------|--------------|--------------|--------------|-----------|-----------------|
| 2025-10 | 445.9M       | 99.64%       | 0.36%        | 0.81%        | 84.3M     | 1.95M           |
| 2025-11 | 418.5M       | 99.65%       | 0.35%        | 0.80%        | 78.3M     | 1.94M           |
| 2025-12 | 460.2M       | 99.67%       | 0.33%        | 0.82%        | 86.1M     | 1.96M           |
| 2026-01 | 476.8M       | 99.66%       | 0.34%        | 0.81%        | 83.4M     | 1.97M           |
| 2026-02 | 425.5M       | 99.65%       | 0.35%        | 0.80%        | 78.4M     | 1.93M           |
| 2026-03 | 493.2M       | 99.68%       | 0.32%        | 0.81%        | 87.4M     | 1.98M           |
| Total   | 3.0B         | 99.66%       | 0.34%        | 0.81%        | ...       | ...             |
```

Use a **Matrix visual** (not Table) so you get automatic totals. Format:
- Condensed font (Segoe UI, 9pt)
- Alternating row colors (white / #F5F5F0)
- Bold total row
- Right-align numbers

**Row 2 — Two charts side by side:**
- Left: **Auth Volume & Success Trend** (Clustered Column + Line combo)
  - Bars = auth_attempts by month
  - Line = auth success rate (secondary axis)
- Right: **Channel Mix** (Donut)
  - OLB vs Mobile vs IVR vs Other

**Navigation buttons at bottom of sidebar:**
- 📊 Auth Details → drills to Child 1
- 🔐 OTP & Step-Up → drills to Child 2
- 👥 Customer View → drills to Child 3
- 📋 Channel & LOB → drills to Child 4

### How to create navigation buttons:
1. Insert > Button > Blank
2. Format: Fill = slightly lighter olive, border = none, text = white
3. Action = Page navigation > select target page
4. Add icon using a text box with emoji or Unicode character

---

### CHILD 1: Digital Authentication Deep Dive

**Matches reference: "Digital Authentication" page (Image 1)**

**Sidebar KPIs:**
- Biometric Logins (auth_method_group = 'Biometric')
- OTP Logins (auth_method_group = 'OTP')
- Passkey Logins (auth_method_group = 'Passkey')
- Unknown/None

**Content — Main Table:**
```
| Year | Month | Channel | Biometric | OTP    | Passkey | None   | Total Auth | Success Rate |
|------|-------|---------|-----------|--------|---------|--------|------------|-------------|
| 2025 | Oct   | Mobile  | ...       | ...    | ...     | ...    | ...        | ...         |
| 2025 | Oct   | OLB     | ...       | ...    | ...     | ...    | ...        | ...         |
```

**Charts:**
- Left: Auth Method Trend by Month (stacked bar)
- Right: Auth Method Proportion (pie/donut)

**← Back button** in top-left of sidebar

**New Spark aggregation needed:**
```python
# v1_auth_method_monthly — for Child 1 table
auth_method_df = spark.sql(f"""
    SELECT
        substr(event_date, 1, 7) AS month,
        CASE
            WHEN application_id IN ('mbank','qd-mobile') THEN 'Mobile'
            WHEN application_id IN ('olb-web','authportal-web','authportal-api') THEN 'OLB'
            WHEN application_id LIKE '%ivr%' THEN 'IVR'
            ELSE 'Other'
        END AS channel,
        CASE
            WHEN authentication_method IN ('fingerprint','face_id','device_biometrics')
                THEN 'Biometric'
            WHEN authentication_method = 'otp' THEN 'OTP'
            WHEN authentication_method = 'device_public_key' THEN 'Passkey'
            WHEN authentication_method = 'placeholder_ic_placeholder'
                THEN 'Unknown'
            ELSE 'None'
        END AS auth_method_group,
        COUNT(*) AS event_cnt,
        SUM(CASE
            WHEN authentication_method IS NOT NULL
                OR token_name IS NOT NULL
                OR source_table = 'PINDROP'
            THEN 1 ELSE 0
        END) AS auth_attempts,
        SUM(CASE
            WHEN failure = 0
                AND (authentication_method IS NOT NULL
                    OR token_name IS NOT NULL
                    OR source_table = 'PINDROP')
            THEN 1 ELSE 0
        END) AS auth_success_cnt,
        SUM(CASE
            WHEN failure = 1
                AND (authentication_method IS NOT NULL
                    OR token_name IS NOT NULL
                    OR source_table = 'PINDROP')
            THEN 1 ELSE 0
        END) AS auth_failure_cnt
    FROM {cfg.OUTPUT_DB}.v1_session_events
    WHERE to_date(event_date) BETWEEN DATE('{SD}') AND DATE('{ED}')
    GROUP BY
        substr(event_date, 1, 7),
        CASE
            WHEN application_id IN ('mbank','qd-mobile') THEN 'Mobile'
            WHEN application_id IN ('olb-web','authportal-web','authportal-api') THEN 'OLB'
            WHEN application_id LIKE '%ivr%' THEN 'IVR'
            ELSE 'Other'
        END,
        CASE
            WHEN authentication_method IN ('fingerprint','face_id','device_biometrics')
                THEN 'Biometric'
            WHEN authentication_method = 'otp' THEN 'OTP'
            WHEN authentication_method = 'device_public_key' THEN 'Passkey'
            WHEN authentication_method = 'placeholder_ic_placeholder'
                THEN 'Unknown'
            ELSE 'None'
        END
""")

cfg.save_to_hive(auth_method_df, "v1_auth_method_monthly")
```

---

### CHILD 2: OTP & Step-Up Analysis

**Matches reference: "OTP Statistics" page (Image 2)**

**Sidebar KPIs:**
- Total OTP Events
- Total Voice Events
- OTP as % of Auth
- Email OTP % vs SMS OTP % (if you have this split — check your token_name field)

**Content — Two side-by-side tables:**

Left table: **Step-Up Counts**
```
| Year | Month | OTP Events | Voice Events | Total Step-Up |
|------|-------|-----------|-------------|---------------|
```

Right table: **Step-Up Percentages**
```
| Year | Month | OTP Rate | Voice Rate | Combined Rate |
|------|-------|----------|-----------|---------------|
```

**Charts:**
- Left: Step-Up Trend (stacked bar — OTP vs Voice by month)
- Right: Step-Up Proportion (pie — OTP vs Voice)

**Data source**: Your existing `v1_digital_auth_kpi_monthly` already has `stepup_type` (OTP/Voice) and `stepup_events`. This child page just needs a Matrix visual filtered to show the step-up rows.

---

### CHILD 3: Customer Adoption & Friction

**Sidebar KPIs:**
- Digitally Active Customers
- Mobile Active Customers ← FIX THIS (still showing 5042)
- OTP Users
- Voice MFA Users

**Content — Table:**
```
| Month   | Digital Active | Mobile Active | OLB Active | OTP Users | Voice Users |
|---------|---------------|--------------|------------|-----------|-------------|
```

**Charts:**
- Left: Adoption by Age Band (clustered bar)
- Right: OTP Exposure by Age Band (bar)

**Data source**: `v1_customer_digital_activity_monthly`

**⚠️ CRITICAL FIX — Mobile Active = 5042:**

This is almost certainly because your `mobile_active_flag` logic is too restrictive, OR you have a filter applied. Check:

```python
# Debug in Spark — run this to verify
spark.sql(f"""
    SELECT
        mobile_active_flag,
        COUNT(*) as cnt,
        COUNT(DISTINCT customer_id) as customers
    FROM {cfg.OUTPUT_DB}.v1_customer_digital_activity_monthly
    GROUP BY mobile_active_flag
""").show()
```

If mobile_active_flag = 1 only has ~5000 rows, then the issue is in your Spark code. Your current logic is:
```sql
MAX(CASE WHEN application_id IN ('mbank','qd-mobile') THEN 1 ELSE 0 END)
```

But `v1_customer_digital_activity_monthly` groups by `user_id` — and the WHERE clause is:
```sql
WHERE user_id RLIKE '^[0-9]+$'  -- RCIF-only customers
```

**Possible cause**: Most mobile app users might have non-numeric user_ids (like device IDs or email-based IDs), so the RCIF filter is excluding them. Check:
```python
# How many distinct users have mobile app events?
spark.sql(f"""
    SELECT
        COUNT(DISTINCT user_id) as all_mobile_users,
        COUNT(DISTINCT CASE WHEN user_id RLIKE '^[0-9]+$' THEN user_id END) as rcif_mobile_users
    FROM {cfg.OUTPUT_DB}.v1_session_events
    WHERE application_id IN ('mbank','qd-mobile')
        AND to_date(event_date) BETWEEN DATE('{SD}') AND DATE('{ED}')
""").show()
```

If `rcif_mobile_users` is ~5000 while `all_mobile_users` is much higher, you've found the bug. The fix is to either:
1. Remove the RCIF filter for mobile (but then customer_dim join breaks), or
2. Create a separate mobile user count that doesn't require RCIF matching

---

### CHILD 4: Channel & LOB Breakdown

**Matches reference: "MFA Applications" page (Image 3) — matrix style**

**Content — Large Matrix:**
```
| Channel | App ID          | LOB Group        | Auth Attempts | Success | Failure | Step-Up | Sessions |
|---------|----------------|-----------------|---------------|---------|---------|---------|----------|
| Mobile  | mbank          | Consumer Banking | ...           | ...     | ...     | ...     | ...      |
| Mobile  | qd-mobile      | Consumer Banking | ...           | ...     | ...     | ...     | ...      |
| OLB     | olb-web        | Consumer Banking | ...           | ...     | ...     | ...     | ...      |
| OLB     | authportal-web | Commercial       | ...           | ...     | ...     | ...     | ...      |
```

Add **Frequency / Percentage / MoM Change** toggle buttons (like Image 3 reference).

**DAX for toggle:**
```dax
// Create a disconnected table for display mode
DisplayMode = DATATABLE("Mode", STRING, {{"Count"}, {"Percentage"}, {"MoM Change"}})

// Measure that switches based on selection
Auth Attempts Display = 
VAR SelectedMode = SELECTEDVALUE(DisplayMode[Mode], "Count")
RETURN
    SWITCH(
        SelectedMode,
        "Count", [Total Auth Attempts],
        "Percentage", DIVIDE([Total Auth Attempts], CALCULATE([Total Auth Attempts], ALL('v1_digital_auth_kpi_monthly')), 0),
        "MoM Change", [Auth Attempts MoM %]
    )
```

**Data source**: Your existing `v1_digital_auth_kpi_monthly` (204 rows) is perfect for this.

---

## POWER BI THEME — DARK SIDEBAR STYLE

Save as `enterprise_auth_v2_theme.json` and import:

```json
{
    "name": "Enterprise Auth v2 — Dark Sidebar",
    "dataColors": [
        "#4472C4",
        "#C0504D",
        "#70AD47",
        "#FFC000",
        "#5B9BD5",
        "#ED7D31",
        "#A5A5A5",
        "#264478"
    ],
    "background": "#FFFFFF",
    "foreground": "#333333",
    "tableAccent": "#4472C4",
    "good": "#70AD47",
    "neutral": "#FFC000",
    "bad": "#C0504D",
    "visualStyles": {
        "*": {
            "*": {
                "general": [{"responsive": true}],
                "title": [{
                    "fontSize": 11,
                    "fontFamily": "Segoe UI Semibold",
                    "fontColor": {"solid": {"color": "#333333"}}
                }],
                "labels": [{
                    "fontSize": 9,
                    "fontFamily": "Segoe UI"
                }]
            }
        },
        "page": {
            "*": {
                "background": [{
                    "color": {"solid": {"color": "#FFFFFF"}},
                    "transparency": 0
                }]
            }
        }
    },
    "textClasses": {
        "callout": {
            "fontSize": 24,
            "fontFace": "Segoe UI Semibold",
            "color": "#FFFFFF"
        },
        "title": {
            "fontSize": 16,
            "fontFace": "Segoe UI Semibold",
            "color": "#000000"
        },
        "header": {
            "fontSize": 11,
            "fontFace": "Segoe UI Semibold",
            "color": "#333333"
        },
        "label": {
            "fontSize": 9,
            "fontFace": "Segoe UI",
            "color": "#666666"
        }
    }
}
```

---

## HOW TO BUILD THE DARK SIDEBAR

Power BI doesn't natively support a sidebar, but the reference dashboards fake it with shapes:

1. **Insert > Shapes > Rectangle**
2. Set fill = #3D3D1E (dark olive), border = none
3. Size: Width = 180px, Height = full page height (720px default)
4. Position: X = 0, Y = 0
5. Send to back (Format > Send backward until behind all visuals)
6. Place your KPI cards, slicers, and filter buttons ON TOP of this rectangle
7. Set all text on the sidebar to white

### KPI Cards on sidebar:
- Use **Card** visual (not New Card)
- Background = transparent
- Category label = white, 9pt
- Data label = white, bold, 20pt
- No border

### Filter buttons:
- Insert > Button > Blank
- Fill = slightly lighter (#5A5A3E)
- Text = white, "Filter OLB Only"
- Action = Bookmark (create bookmarks with pre-set filters)

---

## IMPLEMENTATION ORDER

### Phase 1 — Fix bugs (do first)
1. Fix Auth Success Rate measure (divide by auth_attempts)
2. Debug Mobile Active = 5042 (run the diagnostic queries above)
3. Fix any broken relationships in the data model

### Phase 2 — Build parent page
1. Create the dark sidebar rectangle + style
2. Build the executive summary table (Matrix visual)
3. Add KPI cards to sidebar
4. Add combo chart + donut

### Phase 3 — Build child pages
1. Create 4 blank pages, name them
2. Copy sidebar template to each (copy-paste the rectangle + nav buttons)
3. Build each page's unique content
4. Set up page navigation buttons

### Phase 4 — New Spark table (if needed)
1. Run `v1_auth_method_monthly` code for Child 1
2. Load into Power BI, create relationships
3. Wire up Child 1 visuals

### Phase 5 — Polish
1. Apply theme
2. Add Frequency/Percentage/MoM toggle to Child 4
3. Add "Data As Of" timestamp
4. Test all navigation buttons
5. Test all cross-filters work correctly
6. Publish to workspace

---

## DATA MODEL — UPDATED

```
                    ┌──────────────────────┐
                    │    dim_month         │
                    │  MonthKey (PK)       │
                    │  MonthLabel          │
                    │  MonthStart/End      │
                    └──────────┬───────────┘
                               │ 1:M
        ┌──────────────────────┼──────────────────────┐
        │                      │                      │
        ▼                      ▼                      ▼
┌───────────────────┐ ┌────────────────────┐ ┌────────────────────────────┐
│v1_digital_auth    │ │v1_customer_digital │ │v1_auth_method_monthly      │
│_kpi_monthly       │ │_activity_monthly   │ │(NEW — for Child 1)         │
│                   │ │                    │ │                            │
│month              │ │month               │ │month                       │
│channel            │ │customer_id ────────│─│channel                     │
│application_id     │ │digital_active_flag │ │auth_method_group           │
│lob_group          │ │mobile_active_flag  │ │auth_attempts               │
│stepup_type        │ │otp_user_flag       │ │auth_success_cnt            │
│stepup_events      │ │voice_user_flag     │ │auth_failure_cnt            │
│auth_attempts      │ │olb_active_flag     │ └────────────────────────────┘
│auth_success_cnt   │ └────────┬───────────┘
│auth_failure_cnt   │          │ M:1
│sessions_cnt       │          ▼
└───────────────────┘ ┌────────────────────┐
                      │v1_customer_dim     │
                      │RCIF_CUST_NBR (PK)  │
                      │age_band            │
                      │generation          │
                      │fi_status           │
                      │product_holdings    │
                      └────────────────────┘
```

Relationships:
- dim_month.MonthKey → all fact tables on `month` (1:M)
- v1_customer_dim.RCIF_CUST_NBR → v1_customer_digital_activity_monthly.customer_id (1:M)
- v1_customer_digital_activity_monthly.month → v1_digital_auth_kpi_monthly.month (M:M via dim_month bridge)

---

## TABLE SIZE REFERENCE

| Table | Rows | Role | Loaded in PBI? |
|---|---|---|---|
| v1_session_events | 2.7B | Foundation | NO (too large) |
| v1_digital_auth_kpi_monthly | 204 | Fact (Page 1, Child 2, 4) | YES |
| v1_customer_digital_activity_monthly | 2.9M | Bridge | YES (hidden) |
| v1_customer_dim | 12M | Dimension (slicers) | YES |
| v1_auth_method_monthly | ~200-500 | Fact (Child 1) | YES |
| dim_month | 6 | Calendar | YES |
