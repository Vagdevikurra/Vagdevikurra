"""
STEP 3 — Auth Method Monthly Summary
Purpose: Aggregated fact table for Child 1 (Digital Auth Deep Dive) page
Grain: month × channel × auth_method_group
"""

import v1_config as cfg

spark = cfg.get_spark()

SD = cfg.START_DATE
ED = cfg.END_DATE

print("Building v1_auth_method_monthly ...")

auth_method_df = spark.sql(f"""
    SELECT
        substr(event_date, 1, 7) AS month,

        /* ----------------------
           Channel
           ---------------------- */
        CASE
            WHEN application_id IN ('mbank','qd-mobile') THEN 'Mobile'
            WHEN application_id IN ('olb-web','authportal-web','authportal-api') THEN 'OLB'
            WHEN application_id LIKE '%ivr%' THEN 'IVR'
            ELSE 'Other'
        END AS channel,

        application_id,

        /* ----------------------
           Auth Method Group
           ---------------------- */
        CASE
            WHEN authentication_method IN ('fingerprint','face_id','device_biometrics')
                THEN 'Biometric'
            WHEN authentication_method = 'otp' THEN 'OTP'
            WHEN authentication_method = 'device_public_key' THEN 'Passkey'
            WHEN authentication_method = 'placeholder_ic_placeholder'
                THEN 'Unknown'
            ELSE 'None'
        END AS auth_method_group,

        /* ----------------------
           MFA Type
           ---------------------- */
        CASE
            WHEN authentication_method = 'device_public_key' THEN 'Passkey'
            WHEN authentication_method = 'otp'
                OR token_name IN (
                    'itr_token','rams-token','ivr-token',
                    'authportal-token','idverification-token','rdo-token'
                )
            THEN 'OTP'
            WHEN source_table = 'PINDROP' THEN 'Voice'
            ELSE 'None'
        END AS mfa_type,

        /* ----------------------
           LOB Group
           ---------------------- */
        CASE
            WHEN line_of_business LIKE 'Fraud%' THEN 'Fraud'
            WHEN line_of_business LIKE 'Consumer%' THEN 'Consumer Banking'
            WHEN line_of_business IN (
                'Credit Card','Revolving Credit','Loan Servicing','295 Visa'
            ) THEN 'Credit & Loans'
            WHEN line_of_business IN ('Commercial','Client Services')
                THEN 'Commercial'
            WHEN line_of_business IN ('Private Wealth','Priority')
                THEN 'Wealth / Priority'
            WHEN line_of_business IN (
                '1800 Regions','NC - Branch','4PCbank','GPR','Military Greeting'
            ) THEN 'Channel / Entry'
            WHEN line_of_business = 'New Account' THEN 'New Account'
            ELSE 'Unknown'
        END AS lob_group,

        /* ----------------------
           Metrics
           ---------------------- */
        COUNT(*) AS event_cnt,

        SUM(CASE
            WHEN authentication_method IS NOT NULL
                OR token_name IS NOT NULL
                OR source_table = 'PINDROP'
            THEN 1 ELSE 0
        END) AS auth_attempts,

        SUM(CASE
            WHEN failure = 0
                AND (authentication_method IS NOT NULL
                    OR token_name IS NOT NULL
                    OR source_table = 'PINDROP')
            THEN 1 ELSE 0
        END) AS auth_success_cnt,

        SUM(CASE
            WHEN failure = 1
                AND (authentication_method IS NOT NULL
                    OR token_name IS NOT NULL
                    OR source_table = 'PINDROP')
            THEN 1 ELSE 0
        END) AS auth_failure_cnt,

        COUNT(DISTINCT session_id) AS sessions_cnt,
        COUNT(DISTINCT call_id) AS voice_calls_cnt,

        /* OTP events */
        SUM(CASE
            WHEN authentication_method = 'otp'
                OR token_name IN (
                    'itr_token','rams-token','ivr-token',
                    'authportal-token','idverification-token','rdo-token'
                )
            THEN 1 ELSE 0
        END) AS otp_events_cnt,

        /* Duration */
        AVG(CASE
            WHEN duration < 0 THEN 0
            ELSE CAST(duration AS DOUBLE)
        END) AS avg_duration_sec

    FROM {cfg.OUTPUT_DB}.v1_session_events
    WHERE to_date(event_date) BETWEEN DATE('{SD}') AND DATE('{ED}')
    GROUP BY
        substr(event_date, 1, 7),
        CASE
            WHEN application_id IN ('mbank','qd-mobile') THEN 'Mobile'
            WHEN application_id IN ('olb-web','authportal-web','authportal-api') THEN 'OLB'
            WHEN application_id LIKE '%ivr%' THEN 'IVR'
            ELSE 'Other'
        END,
        application_id,
        CASE
            WHEN authentication_method IN ('fingerprint','face_id','device_biometrics')
                THEN 'Biometric'
            WHEN authentication_method = 'otp' THEN 'OTP'
            WHEN authentication_method = 'device_public_key' THEN 'Passkey'
            WHEN authentication_method = 'placeholder_ic_placeholder'
                THEN 'Unknown'
            ELSE 'None'
        END,
        CASE
            WHEN authentication_method = 'device_public_key' THEN 'Passkey'
            WHEN authentication_method = 'otp'
                OR token_name IN (
                    'itr_token','rams-token','ivr-token',
                    'authportal-token','idverification-token','rdo-token'
                )
            THEN 'OTP'
            WHEN source_table = 'PINDROP' THEN 'Voice'
            ELSE 'None'
        END,
        CASE
            WHEN line_of_business LIKE 'Fraud%' THEN 'Fraud'
            WHEN line_of_business LIKE 'Consumer%' THEN 'Consumer Banking'
            WHEN line_of_business IN (
                'Credit Card','Revolving Credit','Loan Servicing','295 Visa'
            ) THEN 'Credit & Loans'
            WHEN line_of_business IN ('Commercial','Client Services')
                THEN 'Commercial'
            WHEN line_of_business IN ('Private Wealth','Priority')
                THEN 'Wealth / Priority'
            WHEN line_of_business IN (
                '1800 Regions','NC - Branch','4PCbank','GPR','Military Greeting'
            ) THEN 'Channel / Entry'
            WHEN line_of_business = 'New Account' THEN 'New Account'
            ELSE 'Unknown'
        END
""")

print(f"Row count: {auth_method_df.count()}")
auth_method_df.printSchema()

cfg.save_to_hive(auth_method_df, "v1_auth_method_monthly")
print("DONE.")
print(f"{cfg.OUTPUT_DB}.v1_auth_method_monthly")
