"""
DIAGNOSTIC — Debug Mobile Active = 5042
Run these queries in Spark to find the root cause
"""

import v1_config as cfg

spark = cfg.get_spark()
SD = cfg.START_DATE
ED = cfg.END_DATE

# ============================================
# CHECK 1: What does the activity table show?
# ============================================
print("=== CHECK 1: Activity table flag distribution ===")
spark.sql(f"""
    SELECT
        mobile_active_flag,
        COUNT(*) as rows,
        COUNT(DISTINCT customer_id) as customers
    FROM {cfg.OUTPUT_DB}.v1_customer_digital_activity_monthly
    GROUP BY mobile_active_flag
    ORDER BY mobile_active_flag
""").show()

# ============================================
# CHECK 2: How many mobile users exist in raw events?
# ============================================
print("=== CHECK 2: Mobile users in raw events (RCIF vs ALL) ===")
spark.sql(f"""
    SELECT
        COUNT(DISTINCT user_id) as all_mobile_users,
        COUNT(DISTINCT CASE WHEN user_id RLIKE '^[0-9]+$' THEN user_id END) as rcif_mobile_users,
        COUNT(DISTINCT CASE WHEN user_id NOT RLIKE '^[0-9]+$' THEN user_id END) as non_rcif_mobile_users
    FROM {cfg.OUTPUT_DB}.v1_session_events
    WHERE application_id IN ('mbank','qd-mobile')
        AND to_date(event_date) BETWEEN DATE('{SD}') AND DATE('{ED}')
""").show()

# ============================================
# CHECK 3: Sample non-RCIF mobile user_ids
# ============================================
print("=== CHECK 3: Sample non-RCIF mobile user_ids ===")
spark.sql(f"""
    SELECT DISTINCT user_id
    FROM {cfg.OUTPUT_DB}.v1_session_events
    WHERE application_id IN ('mbank','qd-mobile')
        AND user_id NOT RLIKE '^[0-9]+$'
        AND to_date(event_date) BETWEEN DATE('{SD}') AND DATE('{ED}')
    LIMIT 20
""").show(truncate=False)

# ============================================
# CHECK 4: Monthly mobile active trend
# ============================================
print("=== CHECK 4: Monthly mobile active customer count ===")
spark.sql(f"""
    SELECT
        month,
        SUM(mobile_active_flag) as mobile_active_customers,
        SUM(digital_active_flag) as digital_active_customers,
        COUNT(DISTINCT customer_id) as total_customers
    FROM {cfg.OUTPUT_DB}.v1_customer_digital_activity_monthly
    GROUP BY month
    ORDER BY month
""").show()

# ============================================
# CHECK 5: Are mobile events even in source_table types we filter for?
# ============================================
print("=== CHECK 5: Source tables for mobile app events ===")
spark.sql(f"""
    SELECT
        source_table,
        COUNT(*) as event_cnt,
        COUNT(DISTINCT user_id) as users
    FROM {cfg.OUTPUT_DB}.v1_session_events
    WHERE application_id IN ('mbank','qd-mobile')
        AND to_date(event_date) BETWEEN DATE('{SD}') AND DATE('{ED}')
    GROUP BY source_table
    ORDER BY event_cnt DESC
""").show()

# ============================================
# CHECK 6: Does the activity table even have the right
#           source_table filter?
# ============================================
print("=== CHECK 6: Activity table query source filter ===")
print("""
Your activity query has:
  WHERE user_id RLIKE '^[0-9]+$'  -- RCIF-only

But it does NOT filter on source_table.
It checks application_id IN ('mbank','qd-mobile') via MAX(CASE...).

So the question is: do RCIF users (numeric user_ids) actually
appear in rows where application_id = 'mbank' or 'qd-mobile'?
""")

spark.sql(f"""
    SELECT
        COUNT(DISTINCT user_id) as rcif_users_with_mobile_app
    FROM {cfg.OUTPUT_DB}.v1_session_events
    WHERE user_id RLIKE '^[0-9]+$'
        AND application_id IN ('mbank','qd-mobile')
        AND to_date(event_date) BETWEEN DATE('{SD}') AND DATE('{ED}')
""").show()

print("If this number is ~5000, then RCIF users rarely use mobile app.")
print("Most mobile app users likely have non-numeric (device/session) IDs.")
print("")
print("FIX OPTIONS:")
print("  1. Join mobile users to RCIF via a mapping table (if one exists)")
print("  2. Count mobile users separately without RCIF filter")
print("  3. Use a different identifier to link mobile users to customer_dim")
